const ACTIONS = {
    AUTH: 'AUTH'
}

export default ACTIONS