import React from 'react';
import { DM_Sans } from 'next/font/google';
import { useForm } from 'react-hook-form';
import Banner from '../components/globals/Banner';
import NavbarLanding from '../components/globals/NavbarLanding';


const inter = DM_Sans({ subsets: ['latin'] });

export default function Index() {
    const { handleSubmit, register, formState: { errors } } = useForm();

    const onSubmit = (data) => {
        console.log(data);
    };

    return (
        <main className={`min-h-screen bg-[#102815] ${inter.className}`}>
        <NavbarLanding/>
           <Banner/>
        </main>
    );
}
