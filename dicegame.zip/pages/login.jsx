import React from 'react';
import { DM_Sans } from 'next/font/google';
import { useForm } from 'react-hook-form';

const inter = DM_Sans({ subsets: ['latin'] });

export default function Login() {
    const { handleSubmit, register, formState: { errors } } = useForm();

    const onSubmit = (data) => {
        console.log(data);
    };

    return (
        <main className={`min-h-screen bg-[#102815] wow ${inter.className}`}>
            <header className='top-0 left-0 right-0 py-4 px-4 bg-transparent backdrop-blur-sm z-[100] flex items-center text-center border-b-[1px] border-[#4543A9]  justify-center'>
                <h1 className={`text-white text-lg md:text-2xl text-center ${inter.className}`}>Dice - Login 🎲</h1>
            </header>
            <div className="container bg-primary shadow-white/60  shadow-[0_3px_10px_rgb(0,0,0,0.2)] rounded-xl mx-auto p-6 md:w-1/2 w-10/12 text-black mt-8">
                <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
                    <div>
                        <h1 className='text-center text-2xl text-white font-bold'>Login</h1>
                        <p className='text-md text-center text-white'>Welcome Back!</p>
                    </div>

                    <div className="flex flex-col text-white">
                        <label className="">Username</label>
                        <input type="text" {...register('username', { required: true })} className="border rounded-md px-4 p-1 text-black  " />
                        {errors.username && <span className="text-red-500">Username is required</span>}
                    </div>
                    <div className="flex flex-col text-white">
                        <label className="">Password</label>
                        <input type="password" {...register('password', { required: true })} placeholder='******' className="border rounded-md p-1 px-4 text-black " />
                        {errors.password && <span className="text-red-500">Password is required</span>}
                    </div>
                    
                    <div className='flex justify-center '>
                        <button type="submit" className="bg-white/90 md:w-1/2 w-10/12 mt-4 rounded-md text-black p-2">Submit</button>
                    </div>
                    <p className='text-white'>Not an User ?
                      <a href='/register' className='text-green-200 cursor-pointer'> Register Now!</a>
                    </p>
                </form>
            </div>
        </main>
    );
}
