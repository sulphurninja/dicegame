/** @type {import('next').NextConfig} */
const nextConfig = {
  reactStrictMode: true,
  env:{
    baseUrl:'https://localhost:3000'
  }
};

export default nextConfig;
