import React from 'react'
import { Chakra_Petch } from 'next/font/google';
import { Button } from '../ui/button';

const chakra = Chakra_Petch({ subsets: ['latin'], weight: ["300", "400", "500", "600", "700"], });


export default function Banner() {
    return (
        <section id="banner-section" className='flex justify-center leading-[3em] flex-col' >
            <div className={`${chakra.className} text-center `}>
                <h1 className='text-white text-4xl md:text-7xl leading-[4em] font-bold'>PLAY & GAIN</h1>
                <h1 className='text-[#00FEDF] text-4xl md:text-7xl md:mt-4 -mt-9   font-bold'>REWARDS</h1>
            </div>
            <div>

            </div>
            <p className='text-center text-[#D3DBF8]'>Free, Fun & Fair Rewards For Everyone</p>
            <div className='flex justify-center'>
                <Button
                    size={'lg'}
                    className="p-6 md:p-6 mt-4  z-10  mb-8 md:mb-0 md:text-2xl text-xl cursor-pointer  w-fit border-t-2 rounded-full bg-[#7400D3] border-[#4D4D4D] dark:bg-[#7400D3] hover:bg-white hover:text-black group transition-all flex items-center justify-center gap-4 hover:shadow-xl dark:hover:shadow-neutral-500 duration-500"
                >
                    <span className="dark:bg-clip-text uppercase font-bold  text-lg dark:text-transparent cursor-pointer  dark:bg-gradient-to-r from-neutral-500 to-neutral-600 hover:text-black   md:text-center font-sans dark:group-hover:bg-gradient-to-r dark:group-hover:from-black dark:group-hover:to-black">
                        Start Betting!
                    </span>
                </Button>
            </div>
            <div className='flex justify-center mt-8'>
            <img src='/images/top-game-5.png' className='h-full w-64' />

            </div>
        </section>
    )
}
